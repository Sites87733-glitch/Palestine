<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

/*
  🚀 مشروع مدمج: رفع + بناء APK تلقائي
  توكنات
*/

$githubRepo = 'Sites87733-glitch/Palestine';
$githubToken = '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';
$branch = 'main';
$expoToken = 'FOjxfX14IjJqXwvg9Q-rB4xLEzW1uISzmyEwoy0Q';

// 1️⃣ إنشاء ملفات مشروع Expo
$files = [
    'app.json' => json_encode([
        "expo" => [
            "name" => "Palestine",
            "slug" => "palestine",
            "version" => "1.0.0",
            "sdkVersion" => "49.0.0",
            "platforms" => ["android","ios"],
            "android" => ["package"=>"com.palestine.app"]
        ]
    ], JSON_PRETTY_PRINT),

    'package.json' => json_encode([
        "name"=>"palestine",
        "version"=>"1.0.0",
        "main"=>"src/App.js",
        "scripts"=>[
            "start"=>"expo start",
            "android"=>"expo run:android",
            "ios"=>"expo run:ios"
        ],
        "dependencies"=>[
            "expo"=>"^49.0.0",
            "react"=>"18.2.0",
            "react-native"=>"0.72.0"
        ]
    ], JSON_PRETTY_PRINT),

    'eas.json' => json_encode([
        "build"=>[
            "production"=>[
                "android"=>["buildType"=>"apk"]
            ]
        ]
    ], JSON_PRETTY_PRINT),

    'src/App.js' => <<<JS
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>🇵🇸 Palestine App</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, justifyContent:'center', alignItems:'center' },
  text: { fontSize:24, fontWeight:'bold' }
});
JS
];

// إنشاء الملفات
foreach ($files as $path => $content) {
    @mkdir(dirname($path), 0777, true);
    file_put_contents($path, $content);
}

// 2️⃣ إنشاء workflow
$workflowDir = '.github/workflows';
@mkdir($workflowDir, 0777, true);
$workflowFile = $workflowDir.'/expo-build.yml';

file_put_contents($workflowFile, <<<YML
name: Build APK with Expo

on:
  workflow_dispatch:
    inputs:
      build_type:
        description: 'Build Type'
        default: 'apk'

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18'

      - name: Install dependencies
        run: npm install

      - name: Setup Expo EAS
        uses: expo/expo-github-action@v8
        with:
          eas-version: latest
          token: \${{ secrets.EXPO_TOKEN }}

      - name: Build Android APK
        run: eas build --platform android --profile production --non-interactive

      - name: Upload APK artifact
        uses: actions/upload-artifact@v3
        with:
          name: palestine-apk
          path: |
            *.apk
            build/**/*.apk
YML
);

// 3️⃣ دالة لرفع الملفات إلى GitHub
function githubPush($repo, $token, $branch, $filePathLocal, $filePathRemote) {
    // تحقق إذا الملف موجود مسبقًا
    $urlCheck = "https://api.github.com/repos/$repo/contents/$filePathRemote?ref=$branch";
    $ch = curl_init($urlCheck);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: token $token",
        "User-Agent: PHP",
        "Accept: application/vnd.github.v3+json"
    ]);
    $res = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $sha = null;
    if ($httpCode === 200) {
        $resJson = json_decode($res, true);
        $sha = $resJson['sha'] ?? null;
    }

    // رفع الملف
    $url = "https://api.github.com/repos/$repo/contents/$filePathRemote";
    $data = [
        "message" => "Upload $filePathRemote for build",
        "content" => base64_encode(file_get_contents($filePathLocal)),
        "branch" => $branch
    ];
    
    if ($sha) {
        $data['sha'] = $sha;
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: token $token",
        "User-Agent: PHP",
        "Content-Type: application/json",
        "Accept: application/vnd.github.v3+json"
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return [
        'code' => $httpCode,
        'response' => json_decode($response, true)
    ];
}

// 4️⃣ رفع الملفات الأساسية أولاً (بما فيها workflow)
echo "<h3>📤 رفع ملفات المشروع...</h3>";

// رفع ملفات المشروع الرئيسية
$filesToUpload = [
    'app.json',
    'package.json',
    'eas.json',
    'src/App.js',
    '.github/workflows/expo-build.yml'
];

foreach ($filesToUpload as $file) {
    if (file_exists($file)) {
        $result = githubPush($githubRepo, $githubToken, $branch, $file, $file);
        echo "<p>📄 $file: " . ($result['code'] === 200 || $result['code'] === 201 ? '✅' : '❌') . "</p>";
    }
}

// 5️⃣ إنشاء ورفع ZIP
echo "<h3>🗜️ إنشاء ملف ZIP...</h3>";

$zipFile = 'project.zip';
$zip = new ZipArchive();
if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
    die("❌ فشل إنشاء ZIP");
}

$filesIterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(__DIR__));
foreach ($filesIterator as $file) {
    if ($file->isFile() && !str_contains($file->getRealPath(), '.git')) {
        $filePath = $file->getRealPath();
        $localPath = substr($filePath, strlen(__DIR__) + 1);
        if ($localPath !== 'project.zip') {
            $zip->addFile($filePath, $localPath);
        }
    }
}
$zip->close();

// رفع ZIP
$zipResult = githubPush($githubRepo, $githubToken, $branch, $zipFile, 'project.zip');
echo "<p>📦 project.zip: " . ($zipResult['code'] === 200 || $zipResult['code'] === 201 ? '✅' : '❌') . "</p>";

// 6️⃣ الانتظار قليلاً ثم تشغيل Workflow
echo "<h3>⏳ انتظر 3 ثوانٍ...</h3>";
sleep(3);

// 7️⃣ تشغيل Workflow
echo "<h3>🚀 تشغيل GitHub Action...</h3>";

$workflowName = urlencode('expo-build.yml');
$url = "https://api.github.com/repos/$githubRepo/actions/workflows/$workflowName/dispatches";

$data = json_encode([
    "ref" => $branch,
    "inputs" => [
        "build_type" => "apk"
    ]
]);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: token $githubToken",
    "User-Agent: PHP",
    "Content-Type: application/json",
    "Accept: application/vnd.github.v3+json"
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// 8️⃣ عرض النتائج
echo "<h2>🎉 عملية البناء اكتملت!</h2>";

if ($httpCode === 204) {
    echo "<p style='color: green; font-weight: bold;'>✅ تم تشغيل Action بنجاح!</p>";
    echo "<p>يمكنك متابعة البناء من:</p>";
    echo "<ul>";
    echo "<li><a href='https://github.com/Sites87733-glitch/Palestine/actions' target='_blank'>GitHub Actions</a></li>";
    echo "<li><a href='https://expo.dev/accounts/Sites87733-glitch/projects/palestine/builds' target='_blank'>Expo Build Dashboard</a></li>";
    echo "</ul>";
    
    echo "<h3>📱 بعد انتهاء البناء:</h3>";
    echo "<p>سيتم إنشاء APK ويمكن تحميله من:</p>";
    echo "<ol>";
    echo "<li>GitHub Actions → انقر على آخر build → Artifacts</li>";
    echo "<li>Expo Dashboard → Builds → Palestine → Download</li>";
    echo "</ol>";
} else {
    echo "<p style='color: red; font-weight: bold;'>❌ حدث خطأ: HTTP Code $httpCode</p>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
}

// 9️⃣ نظافة الملفات المؤقتة
@unlink($zipFile);
foreach ($files as $path => $content) {
    @unlink($path);
}
@rmdir('src');
@rmdir('.github/workflows');
@rmdir('.github');

echo "<hr>";
echo "<p><strong>ملاحظة:</strong> تأكد من:</p>";
echo "<ul>";
echo "<li>✅ إضافة EXPO_TOKEN إلى GitHub Secrets</li>";
echo "<li>✅ تفعيل GitHub Actions في الـ Repository</li>";
echo "<li>✅ الانتظار 5-10 دقائق حتى يكتمل البناء</li>";
echo "</ul>";
?>