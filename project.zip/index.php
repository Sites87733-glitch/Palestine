<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

/*
  🚀 مشروع مدمج: رفع + بناء APK تلقائي
  مثال القيم (استبدل بالقيم الحقيقية عند الحاجة)
*/

$githubRepo = 'Sites87733-glitch/Palestine'; // GitHub repo كامل
$githubToken = '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'; // Personal Access Token
$branch = 'main';
$expoToken = 'FOjxfX14IjJqXwvg9Q-rB4xLEzW1uISzmyEwoy0Q'; // Expo Token

// 1️⃣ إنشاء ملفات مشروع Expo
$files = [
    'app.json' => json_encode([
        "expo" => [
            "name" => "Palestine",
            "slug" => "palestine",
            "version" => "1.0.0",
            "sdkVersion" => "49.0.0",
            "platforms" => ["android","ios"],
            "android" => ["package"=>"com.palestine.app"]
        ]
    ], JSON_PRETTY_PRINT),

    'package.json' => json_encode([
        "name"=>"palestine",
        "version"=>"1.0.0",
        "main"=>"src/App.js",
        "scripts"=>[
            "start"=>"expo start",
            "android"=>"expo run:android",
            "ios"=>"expo run:ios"
        ],
        "dependencies"=>[
            "expo"=>"^49.0.0",
            "react"=>"18.2.0",
            "react-native"=>"0.72.0"
        ]
    ], JSON_PRETTY_PRINT),

    'eas.json' => json_encode([
        "build"=>[
            "production"=>[
                "android"=>["buildType"=>"apk"]
            ]
        ]
    ], JSON_PRETTY_PRINT),

    'src/App.js' => <<<JS
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>🇵🇸 Palestine App</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, justifyContent:'center', alignItems:'center' },
  text: { fontSize:24, fontWeight:'bold' }
});
JS
];

// إنشاء الملفات
foreach ($files as $path => $content) {
    @mkdir(dirname($path), 0777, true);
    file_put_contents($path, $content);
}

// 2️⃣ إنشاء workflow إذا لم يكن موجود
$workflowDir = '.github/workflows';
@mkdir($workflowDir, 0777, true);
$workflowFile = $workflowDir.'/expo-build.yml';

if(!file_exists($workflowFile)){
    file_put_contents($workflowFile, <<<YML
name: Build APK with Expo

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repo
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 18

      - name: Install dependencies
        run: npm install

      - name: Install EAS CLI
        run: npm install -g eas-cli

      - name: Login to Expo
        run: eas login --token \${{ secrets.EXPO_TOKEN }}

      - name: Build APK
        run: eas build -p android --profile production --non-interactive
YML
    );
}

// 3️⃣ رفع الملفات إلى GitHub (مع التحقق من SHA)
function githubPush($repo, $token, $branch, $filePathLocal, $filePathRemote) {
    // 1. تحقق إذا الملف موجود مسبقًا على GitHub
    $urlCheck = "https://api.github.com/repos/$repo/contents/$filePathRemote?ref=$branch";
    $ch = curl_init($urlCheck);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: token $token",
        "User-Agent: PHP"
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    $resJson = json_decode($res, true);

    $sha = $resJson['sha'] ?? null;

    // 2. رفع الملف
    $url = "https://api.github.com/repos/$repo/contents/$filePathRemote";
    $data = [
        "message" => "Upload $filePathRemote for build",
        "content" => base64_encode(file_get_contents($filePathLocal)),
        "branch" => $branch
    ];
    if($sha) $data['sha'] = $sha; // إذا الملف موجود، نرسل SHA

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: token $token",
        "User-Agent: PHP",
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response,true);
}

// 4️⃣ رفع project.zip
$zipFile = 'project.zip';
$zip = new ZipArchive();
if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
    die("❌ فشل إنشاء ZIP");
}
$filesIterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(__DIR__));
foreach ($filesIterator as $file) {
    if ($file->isFile()) {
        $filePath = $file->getRealPath();
        $localPath = substr($filePath, strlen(__DIR__)+1);
        if($localPath !== 'project.zip') $zip->addFile($filePath, $localPath);
    }
}
$zip->close();

// رفع zip إلى GitHub
$pushRes = githubPush($githubRepo, $githubToken, $branch, $zipFile, 'project.zip');

// 5️⃣ تشغيل GitHub Action بعد رفع workflow
function githubTriggerAction($repo, $token, $branch) {
    $url = "https://api.github.com/repos/$repo/actions/workflows/expo-build.yml/dispatches";
    $data = json_encode(["ref"=>$branch]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: token $token",
        "User-Agent: PHP",
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

$actionRes = githubTriggerAction($githubRepo, $githubToken, $branch);

// 6️⃣ النتائج النهائية
echo "<h2>🚀 عملية رفع المشروع وبناء APK</h2>";

echo "<h3>✅ تم رفع project.zip إلى GitHub</h3>";
echo "<pre>".print_r($pushRes,true)."</pre>";

echo "<h3>✅ تم تشغيل GitHub Action لبدء البناء</h3>";
echo "<pre>".print_r($actionRes,true)."</pre>";

echo "<p>بعد انتهاء Action، رابط APK النهائي سيكون متاحًا على: <br>
<a href='https://expo.dev/accounts/Sites87733-glitch/projects/palestine/builds' target='_blank'>Expo Builds</a></p>";
?>